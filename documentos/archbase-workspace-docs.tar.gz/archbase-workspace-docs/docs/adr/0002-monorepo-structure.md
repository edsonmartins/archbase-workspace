# ADR-002: Estrutura de Monorepo com pnpm + Turborepo

**Status**: Aceito (2025-02-15)

**Decision Makers**: Edson (CTO/Founder)

---

## Contexto e Problema

Projeto terá múltiplos packages interdependentes:

```
archbase-workspace/
├── packages/core        # Desktop shell, window manager
├── packages/sdk         # Plugin SDK (@archbase-workspace/sdk)
├── packages/types       # Shared TypeScript types
├── packages/ui          # Component library
├── packages/state       # State utilities
├── packages/cli         # CLI scaffolding tool
├── apps/desktop         # Host application
└── apps/example-apps/   # Demo federated apps
```

**Requisitos**:
1. Dependências shared sem duplicação (React singleton para MF)
2. Builds paralelos e cacheados
3. TypeScript path aliases funcionando
4. Scripts coordenados (`pnpm build` builda tudo na ordem certa)
5. Hoisting controlado (evitar phantom deps)

### Alternativas Consideradas

#### 1. **npm workspaces**
- ✅ Nativo, sem deps extras
- ❌ Hoisting agressivo (phantom deps)
- ❌ Sem build orchestration
- ❌ Mais lento que pnpm

#### 2. **Yarn workspaces + Lerna**
- ✅ Maduro, bem documentado
- ✅ Lerna para versionamento
- ❌ Lerna pouco mantido (archived em 2022, revived em 2023)
- ❌ yarn.lock menos determinístico que pnpm

#### 3. **pnpm workspaces + Nx**
- ✅ pnpm é o mais rápido e strict
- ✅ Nx tem cache poderoso e affected detection
- ⚠️ Nx é **pesado**: config complexa, curva de aprendizado
- ⚠️ Overkill para projeto que não precisa cloud cache

#### 4. **pnpm workspaces + Turborepo** ⭐ ESCOLHIDO
- ✅ **pnpm strict**: Evita phantom deps (crítico para MF)
- ✅ **Turborepo leve**: Config simples, cache local rápido
- ✅ **Builds paralelos**: Detecta dependências automaticamente
- ✅ **Cache granular**: Cache por task + inputs hash
- ✅ **Vercel mantém**: Mesmo time que Next.js
- ✅ **Remote cache opcional**: Pode adicionar depois
- ⚠️ Menos features que Nx (mas não precisamos)

---

## Decisão

**Usar pnpm workspaces + Turborepo para orchestração de builds.**

### Estrutura de Arquivos

```
archbase-workspace/
├── package.json                 # Root (workspaces)
├── pnpm-workspace.yaml
├── turbo.json                   # Pipeline de builds
├── .npmrc                       # Config pnpm
├── packages/
│   ├── core/
│   │   ├── package.json         # @archbase-workspace/core
│   │   ├── tsconfig.json
│   │   └── rspack.config.js
│   ├── sdk/
│   │   └── package.json         # @archbase-workspace/sdk (publicado npm)
│   └── ...
├── apps/
│   ├── desktop/
│   │   └── package.json         # Host MF
│   └── example-apps/
│       ├── calculator/
│       └── notes/
└── docs/
    ├── adr/
    └── rfcs/
```

### Configuração pnpm

```yaml
# pnpm-workspace.yaml
packages:
  - 'packages/*'
  - 'apps/*'
  - 'apps/example-apps/*'
```

```ini
# .npmrc
# Strict mode - sem phantom deps
auto-install-peers=false
strict-peer-dependencies=true

# Hoisting controlado
shamefully-hoist=false
hoist-pattern[]=*react*
hoist-pattern[]=*@archbase-workspace/sdk*

# Performance
prefer-workspace-packages=true
link-workspace-packages=deep
```

### Configuração Turborepo

```json
// turbo.json
{
  "pipeline": {
    "build": {
      "dependsOn": ["^build"],  // Builda deps primeiro
      "outputs": ["dist/**", ".mf/**"],
      "cache": true
    },
    "dev": {
      "cache": false,
      "persistent": true  // Não mata processo
    },
    "lint": {
      "outputs": [],
      "cache": true
    },
    "test": {
      "dependsOn": ["build"],
      "outputs": ["coverage/**"],
      "cache": true
    },
    "typecheck": {
      "outputs": [],
      "cache": true
    }
  },
  "globalDependencies": [
    "tsconfig.json",
    ".eslintrc.js"
  ]
}
```

### Scripts Coordenados

```json
// package.json (root)
{
  "scripts": {
    "build": "turbo run build",
    "dev": "turbo run dev --parallel",
    "test": "turbo run test",
    "lint": "turbo run lint",
    "clean": "turbo run clean && rm -rf node_modules",
    "typecheck": "turbo run typecheck"
  },
  "devDependencies": {
    "turbo": "^2.3.0",
    "@archbase-workspace/tsconfig": "workspace:*"
  }
}
```

---

## Consequências

### Positivas

1. **Zero phantom dependencies** - pnpm strict mode força declarações explícitas
   - Crítico para MF: Se app remota usa lib não declarada, quebra em prod

2. **Builds 3-5x mais rápidos** - Cache + paralelização
   - Exemplo: `pnpm build` em monorepo limpo: ~15s
   - Com cache Turbo: ~2s (só rebuilda changed packages)

3. **DX superior** - `pnpm dev` sobe todos os apps simultaneamente
   - Desktop shell + 5 apps exemplo rodando com 1 comando

4. **Versionamento simplificado** - Workspace protocol (`workspace:*`)
   ```json
   {
     "dependencies": {
       "@archbase-workspace/sdk": "workspace:*"  // Sempre usa versão local
     }
   }
   ```

5. **TypeScript path aliases funcionam** - Com project references
   ```json
   // tsconfig.json (root)
   {
     "references": [
       { "path": "./packages/core" },
       { "path": "./packages/sdk" }
     ]
   }
   ```

### Negativas

1. **pnpm menos popular** - Alguns devs não conhecem
   - Mitigação: README com onboarding claro

2. **Cache local-only inicialmente** - Sem remote cache
   - Mitigação: Pode adicionar Turbo Remote Cache depois

3. **Curva de aprendizado Turborepo** - Mais simples que Nx, mas não trivial
   - Mitigação: Config minimalista, docs internas

### Trade-offs Aceitos

- **Sacrificamos**: Features avançadas do Nx (affected detection, cloud cache)
- **Ganhamos**: Simplicidade, setup rápido, menos overhead

---

## Métricas de Sucesso

- [ ] `pnpm install` em CI < 30s (com cache)
- [ ] `pnpm build` incremental < 5s
- [ ] Zero erros de phantom deps em prod
- [ ] TypeScript IntelliSense funciona cross-package

---

## Padrões de Nomenclatura

### Packages (scoped)
- `@archbase-workspace/core` - Core do desktop shell
- `@archbase-workspace/sdk` - Plugin SDK (publicado npm)
- `@archbase-workspace/types` - Shared types (publicado npm)
- `@archbase-workspace/ui` - Component library

### Apps (não scoped)
- `desktop` - Host application
- `calculator-app` - Example app
- `notes-app` - Example app

---

## Dependency Management

### Shared Dependencies (críticas para MF)

```json
// packages/core/package.json
{
  "peerDependencies": {
    "react": "^18.3.0",
    "react-dom": "^18.3.0"
  }
}
```

```json
// apps/calculator/package.json
{
  "dependencies": {
    "@archbase-workspace/sdk": "workspace:*"
  },
  "peerDependencies": {
    "react": "^18.3.0",  // MESMO range do core
    "react-dom": "^18.3.0"
  }
}
```

**Regra**: React, ReactDOM, Zustand, Jotai SEMPRE como peerDeps nos packages.

---

## Processo de Publicação (Futura)

### Versioning Strategy (Changeset)

```bash
# Após PR merged
pnpm changeset

# Escolhe packages afetados + tipo (major/minor/patch)
# Gera .changeset/random-id.md

# Release
pnpm changeset version   # Atualiza package.json
pnpm build
pnpm changeset publish   # Publica npm
```

Packages publicados:
- ✅ `@archbase-workspace/sdk` - Plugin SDK
- ✅ `@archbase-workspace/types` - TypeScript types
- ❌ `@archbase-workspace/core` - Privado (parte do desktop)

---

## Referências

- [pnpm workspaces docs](https://pnpm.io/workspaces)
- [Turborepo docs](https://turbo.build/repo/docs)
- [Why pnpm over npm/yarn](https://pnpm.io/feature-comparison)

---

## Notas de Implementação

### Fase 0 (Walking Skeleton)
```bash
# Setup inicial
pnpm init
echo 'packages:\n  - "packages/*"' > pnpm-workspace.yaml
pnpm add -Dw turbo

# Criar primeiro package
mkdir -p packages/core
cd packages/core
pnpm init
```

### Troubleshooting Comum

**Problema**: TypeScript não acha imports cross-package
**Solução**: Adicionar project references + composite mode

**Problema**: Module Federation não acha shared deps
**Solução**: Verificar ranges de peerDependencies (devem ser idênticos)

---

**Última atualização**: 2025-02-15
