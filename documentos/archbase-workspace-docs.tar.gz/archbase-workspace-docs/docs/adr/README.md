# Architecture Decision Records (ADRs)

Este diretório contém as decisões arquiteturais do projeto Archbase Workspace.

## O que é um ADR?

Um ADR documenta uma decisão arquitetural **já tomada**, incluindo:
- Contexto e problema
- Decisão final
- Consequências (positivas e negativas)
- Alternativas consideradas

## Status

- **Aceito**: Decisão está em vigor
- **Proposto**: Em discussão
- **Rejeitado**: Não foi aprovado
- **Superseded**: Substituído por ADR mais recente

---

## Índice

### Core Infrastructure

| # | Título | Status | Data | Tópicos |
|---|--------|--------|------|---------|
| [001](0001-rspack-build-system.md) | Escolha de Rspack como Build System | Aceito | 2025-02-15 | Build, Module Federation, Performance |
| [002](0002-monorepo-structure.md) | Estrutura de Monorepo com pnpm + Turborepo | Aceito | 2025-02-15 | Monorepo, Dependency Management |

### State Management

| # | Título | Status | Data | Tópicos |
|---|--------|--------|------|---------|
| [003](0003-state-management.md) | Zustand para State Global + Jotai para State per-App | Aceito | 2025-02-15 | State, Performance, Module Federation |

### Window Management

| # | Título | Status | Data | Tópicos |
|---|--------|--------|------|---------|
| [004](0004-pointer-events-drag-resize.md) | Pointer Events para Window Drag/Resize | Aceito | 2025-02-15 | Drag & Drop, Performance, Acessibilidade |

---

## Timeline

```
2025-02-15  ADR-001  Rspack Build System
2025-02-15  ADR-002  Monorepo Structure  
2025-02-15  ADR-003  State Management
2025-02-15  ADR-004  Pointer Events
```

---

## Como Criar um ADR?

Veja [CONTRIBUTING.md](../../CONTRIBUTING.md#como-criar-um-adr) para instruções completas.

**Quick start**:

```bash
# 1. Copie template
cp docs/adr/0000-template.md docs/adr/0005-seu-titulo.md

# 2. Preencha seções
# 3. Commit
git add docs/adr/0005-seu-titulo.md
git commit -m "docs: ADR-005 - Seu Título"

# 4. Abra PR
```

---

## Decisões por Categoria

### Build & Tooling
- ADR-001: Rspack
- ADR-002: Monorepo

### Architecture
- ADR-003: State Management
- ADR-004: Pointer Events

### Performance
- ADR-001: Rspack (builds 10x faster)
- ADR-003: Zustand (granular selectors)
- ADR-004: rAF + GPU acceleration

### Developer Experience
- ADR-002: pnpm (strict deps)
- ADR-003: Zero boilerplate state
- ADR-004: Type-safe drag/resize

---

## Superseded ADRs

Nenhum ainda.

---

## Rejected ADRs

Nenhum ainda.

---

**Última atualização**: 2025-02-15
