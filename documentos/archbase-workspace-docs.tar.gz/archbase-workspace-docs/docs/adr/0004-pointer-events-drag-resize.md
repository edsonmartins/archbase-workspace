# ADR-004: Pointer Events para Window Drag/Resize (não HTML5 Drag API)

**Status**: Aceito (2025-02-15)

**Decision Makers**: Edson (CTO/Founder)

---

## Contexto e Problema

Window management precisa de drag & drop sofisticado:

1. **Drag**: Mover janelas com mouse/touch
2. **Resize**: 8 handles (4 cantos + 4 bordas)
3. **Snap**: Alinhar em grids/outras janelas (Windows 11 style)
4. **Performance**: 60fps com 50+ janelas
5. **Touch**: Funcionar em tablets/touch screens
6. **Cursor**: Mudar visual durante drag/resize

### Alternativas Consideradas

#### 1. **HTML5 Drag and Drop API**
```jsx
<div draggable="true" onDrag={handleDrag}>Window</div>
```

- ✅ Nativo do browser
- ❌ **Não serve para nosso caso**:
  - Não controla posição durante drag (só no drop)
  - Ghost image não customizável adequadamente
  - Performance ruim (dispara eventos demais)
  - API bizarra (`dataTransfer`, `effectAllowed`)
  - Não funciona bem para resize
  - Touch support problemático

#### 2. **react-dnd (biblioteca)**
- ✅ Abstração sobre HTML5 Drag API
- ✅ Multi-backend (HTML5 + Touch)
- ✅ Usado em muitos projetos
- ❌ **Overkill para nosso caso**:
  - 25KB minified (só pra drag)
  - Complexidade desnecessária (monitors, collectors, connectors)
  - Baseado em HTML5 Drag API (herda limitações)
  - Não foi feito para window management

```jsx
// Exemplo react-dnd (verboso demais)
const [{ isDragging }, drag] = useDrag({
  type: 'WINDOW',
  item: { id: windowId },
  collect: (monitor) => ({ isDragging: monitor.isDragging() })
});
```

#### 3. **react-draggable**
- ✅ Simples, API direta
- ✅ 12KB, leve
- ✅ Funciona bem
- ⚠️ Wrapper em volta de elemento
- ⚠️ Menos controle sobre performance
- ⚠️ Ainda adiciona abstração sobre Pointer Events

#### 4. **Pointer Events API (nativo)** ⭐ ESCOLHIDO
```jsx
<div
  onPointerDown={handlePointerDown}
  onPointerMove={handlePointerMove}
  onPointerUp={handlePointerUp}
>
  Window
</div>
```

- ✅ **Nativo do browser** (zero dependencies)
- ✅ **Performance máxima** (controle total)
- ✅ **Unificado**: Mouse + Touch + Pen em 1 API
- ✅ **Controle fino**: requestAnimationFrame, throttling manual
- ✅ **Transform-based**: GPU acceleration fácil
- ✅ **Cursor customizado**: CSS `cursor` property
- ✅ **Pointer capture**: `setPointerCapture()` para não perder eventos

---

## Decisão

**Implementar drag & resize usando Pointer Events API nativamente, sem bibliotecas.**

### Justificativa

1. **Performance é crítica**: 50+ janelas requer controle absoluto
2. **Flexibilidade**: Queremos snap customizado, magnetic edges, etc
3. **Bundle size**: Zero overhead (API é nativa)
4. **Touch first-class**: Pointer Events unifica mouse e touch
5. **GPU acceleration**: `transform: translate3d()` é trivial

---

## Implementação Detalhada

### Drag com Pointer Events

```typescript
// packages/core/src/components/Window/useDrag.ts
import { useRef, useCallback } from 'react';
import { useWindowsStore } from '@archbase-workspace/state';

interface DragState {
  isDragging: boolean;
  startX: number;
  startY: number;
  startPos: { x: number; y: number };
}

export function useDrag(windowId: string) {
  const dragState = useRef<DragState | null>(null);
  const rafId = useRef<number | null>(null);
  const updatePosition = useWindowsStore((s) => s.updatePosition);
  
  const handlePointerDown = useCallback((e: React.PointerEvent) => {
    // Só inicia drag se clicar no header
    if (!(e.target as HTMLElement).closest('[data-window-header]')) {
      return;
    }
    
    e.preventDefault();
    
    // Captura pointer (eventos seguem mesmo fora do elemento)
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
    
    const window = useWindowsStore.getState().windows.get(windowId);
    if (!window) return;
    
    dragState.current = {
      isDragging: true,
      startX: e.clientX,
      startY: e.clientY,
      startPos: window.position
    };
    
    // Muda cursor
    document.body.style.cursor = 'grabbing';
    
    // Foca janela
    useWindowsStore.getState().focusWindow(windowId);
  }, [windowId]);
  
  const handlePointerMove = useCallback((e: React.PointerEvent) => {
    if (!dragState.current?.isDragging) return;
    
    // Cancela rAF anterior (throttling)
    if (rafId.current) {
      cancelAnimationFrame(rafId.current);
    }
    
    // Agenda update no próximo frame
    rafId.current = requestAnimationFrame(() => {
      const { startX, startY, startPos } = dragState.current!;
      
      const deltaX = e.clientX - startX;
      const deltaY = e.clientY - startY;
      
      const newPosition = {
        x: startPos.x + deltaX,
        y: startPos.y + deltaY
      };
      
      // Snap to edges (opcional)
      const snapped = snapToEdges(newPosition);
      
      updatePosition(windowId, snapped);
    });
  }, [windowId, updatePosition]);
  
  const handlePointerUp = useCallback((e: React.PointerEvent) => {
    if (!dragState.current?.isDragging) return;
    
    (e.target as HTMLElement).releasePointerCapture(e.pointerId);
    
    dragState.current = null;
    document.body.style.cursor = '';
    
    if (rafId.current) {
      cancelAnimationFrame(rafId.current);
      rafId.current = null;
    }
  }, []);
  
  return {
    dragHandlers: {
      onPointerDown: handlePointerDown,
      onPointerMove: handlePointerMove,
      onPointerUp: handlePointerUp
    }
  };
}
```

### Resize com 8 Handles

```typescript
// packages/core/src/components/Window/useResize.ts
type ResizeHandle = 'n' | 'ne' | 'e' | 'se' | 's' | 'sw' | 'w' | 'nw';

const CURSORS: Record<ResizeHandle, string> = {
  n: 'ns-resize',
  ne: 'nesw-resize',
  e: 'ew-resize',
  se: 'nwse-resize',
  s: 'ns-resize',
  sw: 'nesw-resize',
  w: 'ew-resize',
  nw: 'nwse-resize'
};

export function useResize(windowId: string) {
  const resizeState = useRef<{
    handle: ResizeHandle;
    startX: number;
    startY: number;
    startSize: { width: number; height: number };
    startPos: { x: number; y: number };
  } | null>(null);
  
  const handleResizeStart = useCallback((handle: ResizeHandle) => (e: React.PointerEvent) => {
    e.preventDefault();
    e.stopPropagation(); // Não dispara drag
    
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
    
    const window = useWindowsStore.getState().windows.get(windowId);
    if (!window) return;
    
    resizeState.current = {
      handle,
      startX: e.clientX,
      startY: e.clientY,
      startSize: window.size,
      startPos: window.position
    };
    
    document.body.style.cursor = CURSORS[handle];
  }, [windowId]);
  
  const handleResizeMove = useCallback((e: React.PointerEvent) => {
    if (!resizeState.current) return;
    
    const { handle, startX, startY, startSize, startPos } = resizeState.current;
    
    const deltaX = e.clientX - startX;
    const deltaY = e.clientY - startY;
    
    let newSize = { ...startSize };
    let newPos = { ...startPos };
    
    // Lógica por handle
    if (handle.includes('e')) {
      newSize.width = Math.max(200, startSize.width + deltaX);
    }
    if (handle.includes('w')) {
      const proposedWidth = Math.max(200, startSize.width - deltaX);
      newPos.x = startPos.x + (startSize.width - proposedWidth);
      newSize.width = proposedWidth;
    }
    if (handle.includes('s')) {
      newSize.height = Math.max(150, startSize.height + deltaY);
    }
    if (handle.includes('n')) {
      const proposedHeight = Math.max(150, startSize.height - deltaY);
      newPos.y = startPos.y + (startSize.height - proposedHeight);
      newSize.height = proposedHeight;
    }
    
    requestAnimationFrame(() => {
      useWindowsStore.getState().updateSize(windowId, newSize);
      if (newPos.x !== startPos.x || newPos.y !== startPos.y) {
        useWindowsStore.getState().updatePosition(windowId, newPos);
      }
    });
  }, [windowId]);
  
  return { handleResizeStart, handleResizeMove };
}
```

### Window Component

```tsx
// packages/core/src/components/Window/Window.tsx
export function Window({ id }: { id: string }) {
  const window = useWindow(id);
  const { dragHandlers } = useDrag(id);
  const { handleResizeStart, handleResizeMove } = useResize(id);
  
  if (!window) return null;
  
  return (
    <div
      className="window"
      style={{
        position: 'absolute',
        // GPU-accelerated positioning
        transform: `translate3d(${window.position.x}px, ${window.position.y}px, 0)`,
        width: window.size.width,
        height: window.size.height,
        zIndex: window.zIndex,
        // Performance hints
        willChange: window.isDragging ? 'transform' : 'auto'
      }}
      {...dragHandlers}
    >
      {/* Header (drag handle) */}
      <div data-window-header className="window-header">
        {window.title}
      </div>
      
      {/* Content */}
      <div className="window-content">
        <RemoteApp appId={window.appId} />
      </div>
      
      {/* 8 Resize handles */}
      {(['n', 'ne', 'e', 'se', 's', 'sw', 'w', 'nw'] as const).map((handle) => (
        <div
          key={handle}
          className={`resize-handle resize-handle-${handle}`}
          onPointerDown={handleResizeStart(handle)}
          onPointerMove={handleResizeMove}
          style={{
            cursor: CURSORS[handle]
          }}
        />
      ))}
    </div>
  );
}
```

### CSS para Handles

```css
/* packages/core/src/components/Window/Window.css */
.window {
  contain: layout style paint; /* Otimização de rendering */
  user-select: none; /* Evita seleção de texto durante drag */
}

.resize-handle {
  position: absolute;
  z-index: 10;
}

/* Bordas */
.resize-handle-n { top: 0; left: 0; right: 0; height: 4px; }
.resize-handle-s { bottom: 0; left: 0; right: 0; height: 4px; }
.resize-handle-e { right: 0; top: 0; bottom: 0; width: 4px; }
.resize-handle-w { left: 0; top: 0; bottom: 0; width: 4px; }

/* Cantos */
.resize-handle-ne { top: 0; right: 0; width: 8px; height: 8px; }
.resize-handle-se { bottom: 0; right: 0; width: 8px; height: 8px; }
.resize-handle-sw { bottom: 0; left: 0; width: 8px; height: 8px; }
.resize-handle-nw { top: 0; left: 0; width: 8px; height: 8px; }
```

---

## Consequências

### Positivas

1. **Zero dependencies** - Não adiciona peso ao bundle
2. **Performance otimizada** - rAF + throttling manual
3. **GPU acceleration** - `transform: translate3d()`
4. **Touch funciona** - Pointer Events unifica tudo
5. **Controle total** - Snap, magnetic edges, qualquer heurística customizada

### Negativas

1. **Código próprio** - Mantemos nossa implementação
   - Mitigação: Testes extensivos, bem documentado
   
2. **Edge cases** - Precisamos lidar manualmente
   - Pointer capture perdido
   - Multi-touch
   - Ponteiro saindo da viewport
   - Mitigação: Casos cobertos por testes

3. **Acessibilidade** - Drag via keyboard precisa de implementação separada
   - Mitigação: Arrow keys + modifier para mover/resize

### Performance Optimizations

1. **requestAnimationFrame**: Throttling para 60fps
2. **will-change**: Apenas durante drag ativo (economiza memória)
3. **transform vs top/left**: GPU-accelerated
4. **Pointer capture**: Eventos continuam mesmo fora do elemento
5. **Cancelamento de rAF**: Evita queue buildup

---

## Snap e Magnetic Edges (Futuro)

```typescript
// packages/core/src/utils/snap.ts
const SNAP_THRESHOLD = 20; // pixels
const MAGNETIC_THRESHOLD = 10; // pixels

function snapToEdges(position: { x: number; y: number }) {
  const viewport = { width: window.innerWidth, height: window.innerHeight };
  
  // Snap to viewport edges
  if (Math.abs(position.x) < SNAP_THRESHOLD) {
    position.x = 0;
  }
  if (Math.abs(position.y) < SNAP_THRESHOLD) {
    position.y = 0;
  }
  
  // Snap to other windows (magnetic)
  const otherWindows = useWindowsStore.getState().windows;
  for (const [id, otherWindow] of otherWindows) {
    if (id === windowId) continue;
    
    const distanceX = Math.abs(position.x - otherWindow.position.x);
    const distanceY = Math.abs(position.y - otherWindow.position.y);
    
    if (distanceX < MAGNETIC_THRESHOLD) {
      position.x = otherWindow.position.x;
    }
    if (distanceY < MAGNETIC_THRESHOLD) {
      position.y = otherWindow.position.y;
    }
  }
  
  return position;
}
```

---

## Acessibilidade

### Keyboard Support (Fase futura)

```typescript
// Mover janela com keyboard
function useKeyboardMove(windowId: string) {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isFocused(windowId)) return;
      
      const STEP = e.shiftKey ? 10 : 1; // Shift = faster
      
      switch (e.key) {
        case 'ArrowUp':
          moveBy(0, -STEP);
          break;
        case 'ArrowDown':
          moveBy(0, STEP);
          break;
        case 'ArrowLeft':
          moveBy(-STEP, 0);
          break;
        case 'ArrowRight':
          moveBy(STEP, 0);
          break;
      }
    };
    
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [windowId]);
}
```

### ARIA

```tsx
<div
  role="dialog"
  aria-labelledby={`window-title-${id}`}
  aria-describedby={`window-content-${id}`}
  tabIndex={-1}
>
  <div
    id={`window-title-${id}`}
    data-window-header
    role="heading"
    aria-level={2}
  >
    {title}
  </div>
</div>
```

---

## Testing

```typescript
// packages/core/src/components/Window/__tests__/drag.test.ts
import { render, fireEvent } from '@testing-library/react';
import { Window } from '../Window';

describe('Window drag', () => {
  it('moves window on pointer drag', () => {
    const { getByTestId } = render(<Window id="test-1" />);
    const header = getByTestId('window-header');
    
    // Simula drag de 100px pra direita
    fireEvent.pointerDown(header, { clientX: 0, clientY: 0 });
    fireEvent.pointerMove(header, { clientX: 100, clientY: 0 });
    fireEvent.pointerUp(header);
    
    const window = useWindowsStore.getState().windows.get('test-1');
    expect(window?.position.x).toBe(100);
  });
  
  it('does not drag when clicking content', () => {
    const { getByTestId } = render(<Window id="test-1" />);
    const content = getByTestId('window-content');
    
    fireEvent.pointerDown(content, { clientX: 0, clientY: 0 });
    fireEvent.pointerMove(content, { clientX: 100, clientY: 0 });
    fireEvent.pointerUp(content);
    
    const window = useWindowsStore.getState().windows.get('test-1');
    expect(window?.position.x).toBe(0); // Não moveu
  });
});
```

---

## Métricas de Sucesso

- [ ] 60fps durante drag com 50+ janelas
- [ ] Latência < 16ms (1 frame) entre pointer move e visual update
- [ ] Touch funciona sem bugs em tablets
- [ ] Zero memory leaks após 1000 drags
- [ ] Cursor correto em todos os handles

---

## Referências

- [Pointer Events MDN](https://developer.mozilla.org/en-US/docs/Web/API/Pointer_events)
- [setPointerCapture](https://developer.mozilla.org/en-US/docs/Web/API/Element/setPointerCapture)
- [requestAnimationFrame optimization](https://developer.mozilla.org/en-US/docs/Web/API/window/requestAnimationFrame)
- [will-change CSS](https://developer.mozilla.org/en-US/docs/Web/CSS/will-change)

---

**Última atualização**: 2025-02-15  
**Revisão necessária**: Se performance issues aparecerem em produção
