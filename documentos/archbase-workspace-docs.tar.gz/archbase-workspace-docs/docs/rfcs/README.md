# Request for Comments (RFCs)

Este diretório contém propostas de features e mudanças substanciais para o Archbase Workspace.

## O que é um RFC?

Um RFC propõe uma mudança **futura** para discussão pública, incluindo:
- Motivação (por que precisamos disso?)
- Design detalhado (como vai funcionar?)
- Tradeoffs (drawbacks)
- Alternativas consideradas
- Estratégia de adoção

## Status

- **Draft**: Escrita inicial, ainda incompleto
- **Discussion**: Aberto para feedback (7 dias default)
- **Final Comment Period**: Últimas objeções (3 dias)
- **Accepted**: Aprovado, pronto para implementar
- **Rejected**: Não aprovado
- **Implemented**: Já implementado

---

## Índice

### Core APIs

| # | Título | Status | Author | Discussion Period |
|---|--------|--------|--------|-------------------|
| [001](0001-window-service-api.md) | Window Service API Design | Discussion | Edson | 2025-02-15 to 2025-02-22 |
| [002](0002-app-manifest-structure.md) | App Manifest Structure | Discussion | Edson | 2025-02-15 to 2025-02-22 |

---

## Timeline

```
2025-02-15  RFC-001  Window Service API       [Discussion]
2025-02-15  RFC-002  App Manifest Structure   [Discussion]
```

---

## Como Criar um RFC?

Veja [CONTRIBUTING.md](../../CONTRIBUTING.md#como-criar-um-rfc) para instruções completas.

**Quick start**:

```bash
# 1. Copie template
cp docs/rfcs/0000-template.md docs/rfcs/0003-seu-titulo.md

# 2. Preencha seções
# 3. Commit como DRAFT
git add docs/rfcs/0003-seu-titulo.md
git commit -m "docs: RFC-003 - Seu Título [DRAFT]"

# 4. Abra PR para discussão
# 5. Incorpore feedback
# 6. Final Comment Period (3 dias)
# 7. Decision: Accept ou Reject
```

---

## RFCs por Categoria

### Window Management
- RFC-001: Window Service API

### Module Federation
- RFC-002: App Manifest Structure

### Plugin System
- (Futuro) RFC-003: Activation Events
- (Futuro) RFC-004: Permission System

---

## Active Discussions

| RFC | Topic | Deadline | Link |
|-----|-------|----------|------|
| 001 | Window Service API | 2025-02-22 | [PR #X](#) |
| 002 | App Manifest | 2025-02-22 | [PR #Y](#) |

---

## Accepted RFCs

Nenhum ainda (todos em discussão).

---

## Rejected RFCs

Nenhum ainda.

---

## Implemented RFCs

Nenhum ainda.

---

## Processo de Discussão

### 1. Draft Phase
- Author escreve RFC
- Compartilha com core team informalmente
- Refina baseado em feedback inicial

### 2. Discussion Phase (7 dias)
- Abre PR no GitHub
- Label `rfc` + `discussion`
- Community comenta
- Author atualiza RFC

### 3. Final Comment Period (3 dias)
- Após consenso emergir
- Label `final-comment-period`
- Últimas objeções
- Decision deadline definida

### 4. Resolution
- **Accepted**: Merge PR, status → Accepted
- **Rejected**: Close PR, documentar razões
- **Deferred**: Pausado, pode revisitar

---

## Guidelines para Revisores

Ao revisar RFC, considere:

✅ **Aprovar se**:
- Motivação clara e convincente
- Design bem pensado
- Considera tradeoffs honestamente
- Alternativas exploradas
- Estratégia de adoção viável

❌ **Questionar se**:
- Motivação fraca ("seria legal ter")
- Design incompleto ou vago
- Ignora drawbacks óbvios
- Não considera alternativas
- Breaking changes não justificadas

💬 **Sempre**:
- Seja construtivo
- Sugira melhorias
- Compartilhe experiência relevante
- Aponte problemas com soluções

---

## Templates

- [RFC Template](0000-template.md)
- [ADR Template](../adr/0000-template.md)

---

**Última atualização**: 2025-02-15
